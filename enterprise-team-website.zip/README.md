# Enterprise Team Website
An angularJS one page website developed for Enterprise Gym at Dundee University.

## Installation
- bower dependencies: ```bower install```

## Requirements
- Enterprise Java Spring Backend
