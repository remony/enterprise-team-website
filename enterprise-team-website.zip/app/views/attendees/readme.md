# updating attendence
# send in
- token of user
- attendee id : the person who you select
- attendence value: 1 or 0

/event/:id/participants  POST